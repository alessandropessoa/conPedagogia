from django.db import models as bd
import os
from tinymce.models import HTMLField

# Create your models here.
class heroSection(bd.Model):
    imagemBanner    = bd.ImageField("Imagem do Banner",upload_to="imgBanner",blank=True,null=True)
    dataCriacao     = bd.DateTimeField(verbose_name='Data Criação',auto_now=True,auto_now_add=False)
    def __str__(self):
        return str(self.id)
    class Meta:
        verbose_name = 'Home - Logo'
        ordering = ["-dataCriacao"]
        

class descricao(bd.Model):
    titulo  	       = bd.TextField("Titulo do sobre",  max_length=200,blank=True,null=True)
    descricaoSupra	   = bd.TextField('Descrição Supra', max_length=808,blank=True,null=True)
    descricaoInfra	   = bd.TextField('Descrição Infra', max_length=300,blank=True,null=True)
    imagemDescricao    = bd.ImageField("Imagem Lateral Descricao",upload_to="imgDescricao",blank=True,null=True)
    dataCriacao     = bd.DateTimeField(verbose_name='Data Criação',auto_now=True,auto_now_add=False)
    
    def __str__(self):
        return self.titulo
    class Meta:
        verbose_name = 'Home - Descrição'
        verbose_name_plural = 'Home - Descrições'
        ordering = ["titulo","dataCriacao"]
        
 
class comoFunciona(bd.Model):
    duvida = HTMLField()
    solucao = HTMLField()
    dataCriacao     = bd.DateTimeField(verbose_name='Data Criação',auto_now=True)
    def __str__(self):
        return self.duvida
    class Meta:
        verbose_name = 'Home - Como Funciona'
        ordering = ["dataCriacao"]
 
 
class portifolio(bd.Model):
    titulo  	 = bd.CharField("Titulo",  max_length=200,blank=True,null=True)   
    texto = HTMLField()
    url         = bd.URLField("URL ",blank=True,null=True)
    imagem      = bd.ImageField("Imagem da Home", upload_to="imgPortifolio",blank=True,null=True)
    dataCriacao = bd.DateTimeField(verbose_name='Data Criação',auto_now=True)
    
    class Meta:
        verbose_name = 'Home - Portifolio'
        verbose_name_plural = 'Home -Portifolios'
        ordering = ["-dataCriacao","titulo"]
        
        
class listaConcursos(bd.Model):
    titulo  	 = bd.CharField("Titulo",  max_length=200,blank=True,null=True)
    descricao	   = bd.TextField('Descrição', max_length=808,blank=True,null=True)  
    url         = bd.URLField("URL",blank=True,null=True)
    dataCriacao = bd.DateTimeField(verbose_name='Data Criação',auto_now=True)
    def __str__(self):
        return self.titulo
    class Meta:
        verbose_name = 'Home - Lista de Concursos'
        verbose_name_plural = 'Home - Lista de Concursos'
        ordering = ["-dataCriacao","titulo"]


class msg(bd.Model):
    nome            = bd.CharField('Nome', max_length=60)
    email           = bd.CharField('Email ', max_length=108)
    cpf             = bd.CharField('CPF ', max_length=15,blank=True,null=True)
    telefone        = bd.CharField('Telefone ', max_length=20)
    descricao       = bd.TextField('Descrição', max_length=808,blank=True,null=True)
    dataCriacao     = bd.DateTimeField(verbose_name='Data Criação',auto_now=True)
    def __str__(self):
        return self.nome
    class Meta:
        verbose_name = 'Home - Mensagem'
        verbose_name_plural = 'Home - Mensagens' 


class redeSocial(bd.Model):
    opcao_redeSocial = (("twitter","twitter"),
				("facebook","facebook"),
				("instagram","instagram"),
				("skype","skype"),
				("telegram","telegram"),
				("pinterest","pinterest"),
				("linkedin","linkedin"),
                ("zoom","zoom"),
				("youtube","youtube"),
				)
	
    nomeRedeSocial  	= bd.CharField("Nome da Rede Social", choices = opcao_redeSocial, default="facebook", max_length=20)
    urlRedeSocial	    = bd.CharField('Url Da Rede Sociai', max_length=40)
    dataCriacao         = bd.DateTimeField(verbose_name='Data Criação',auto_now=True,auto_now_add=False)
    def __str__(self):
        return self.nomeRedeSocial 
    class Meta:
        verbose_name = 'Home - Rede Social'
        verbose_name_plural = 'Home - Redes  Sociais'
        ordering = ["nomeRedeSocial","dataCriacao"]


class estilo(bd.Model):
    estilo = 'Estilo'
    bgColor    = bd.CharField("Cor de Fundo",default="dcdcdc",  max_length=10,help_text="Cor de fundo da pagina.")
    def __str__(self):
        return self.estilo
    class Meta:
        verbose_name = 'Home - Estilo'
        verbose_name_plural = 'Home - Estilo' 

class formsHome(bd.Model):
    opcao_estados = (("Acre","AC"),	("Alagoas","AL"),("Amapá","AP"),("Amazonas","AM"),
                ("Bahia","BA"),("Ceará","CE"),("Espírito Santo","ES"),("Goiás","GO"),
                 ("Maranhão","MA"), ("Mato Grosso","MT"),   ("Mato Grosso do Sul","MS"), ("Minas Gerais","MG"),
                ("Pará","PA"), ("Paraíba","PB"),("Paraná","PR"),("Pernambuco","PE"),
                ("Piauí","PI"),("Rio de Janeiro","RJ"),("Rio Grande do Norte","RN"),("Rio Grande do Sul","RS"),
                ("Rondônia","RO"), ("Roraima","RR"),("Santa Catarina","SC"),("São Paulo","SP"),
                ("Sergipe","SE"),("Tocantins","TO"),("Distrito Federal","DF"),
				)
  	
    nome        = bd.CharField('Nome ', max_length=100)
    cpf         = bd.CharField('CPF ', max_length=15)
    email       = bd.CharField('Email ', max_length=108)
    nascimento  = bd.CharField('Data de Nascimento ', max_length=18)
    endereco    = bd.CharField('Endereço ', max_length=108)
    bairro      = bd.CharField('Bairro ', max_length=48)   
    cidade      = bd.CharField('Cidade', max_length=38)
    estado      = bd.CharField("Estado", choices = opcao_estados, default="RJ", max_length=20)
    estadoCivil = bd.CharField('Estado Civil ', max_length=20)
    cep         = bd.CharField('Cep ', max_length=15)
    telefone    = bd.CharField('Telefone ', max_length=20)
    dataCriacao         = bd.DateTimeField(verbose_name='Data Criação',auto_now=True,auto_now_add=False)
    def __str__(self):
        return self.cpf
    class Meta:
        verbose_name = 'Home - Cliente'
        verbose_name_plural = 'Home - Clientes' 

"""  
class categoriasMenu(bd.Model):
    titulo          = bd.CharField("Titulo ",max_length=30)
    url             = bd.URLField("URL ",blank=True,null=True)
    dataCriacao     = bd.DateTimeField(verbose_name='Data Criação',auto_now=True)
    def __str__(self):
        return self.titulo
    class Meta:
        verbose_name = 'Categoria - Menu'


class categorias(bd.Model):
    titulo          = bd.CharField("Titulo ",max_length=30,blank=True,null=True)
    descricao       = bd.TextField('Descrição ', max_length=808,blank=True,null=True)
    imagemBanner    = bd.ImageField("Imagem di Post",upload_to="imgCategorias",blank=True,null=True)
    url             = bd.URLField("URL ",blank=True,null=True)
    dataCriacao     = bd.DateTimeField(verbose_name='Data Criação',auto_now=True)
    def __str__(self):
        return self.titulo
    class Meta:
        verbose_name = 'Categoria - Post'
        verbose_name_plural = 'Categoria - Posts'
    




       
"""
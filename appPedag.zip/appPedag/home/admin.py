from django.contrib import admin
from .models import *

# Register your models here.
class heroSectionAdmin(admin.ModelAdmin):
	list_display 	= ['dataCriacao']
	search_fields = ["dataCriacao"]
admin.site.register(heroSection,heroSectionAdmin)

class descricaoAdmin(admin.ModelAdmin):
	list_display 	= ["titulo",'dataCriacao','descricaoSupra']
	search_fields = ["dataCriacao"]
admin.site.register(descricao,descricaoAdmin)

class comoFuncionaAdmin(admin.ModelAdmin):
	list_display 	= ["duvida",'solucao','dataCriacao']
	search_fields = ["dataCriacao",'dataCriacao']
admin.site.register(comoFunciona,comoFuncionaAdmin)

class portifolioAdmin(admin.ModelAdmin):
	list_display 	= ["titulo",'texto','dataCriacao']
	search_fields = ["titulo",'dataCriacao']
admin.site.register(portifolio,portifolioAdmin)

class listaConcursosAdmin(admin.ModelAdmin):
	list_display 	= ["titulo",'descricao','dataCriacao']
	search_fields = ["titulo",'dataCriacao']
admin.site.register(listaConcursos,listaConcursosAdmin)

class msgAdmin(admin.ModelAdmin):
	list_display 	= ["nome",'descricao','dataCriacao']
	search_fields = ['dataCriacao',"nome"]
admin.site.register(msg,msgAdmin)

class redeSocialAdmin(admin.ModelAdmin):
	list_display 	= ["nomeRedeSocial",'dataCriacao','dataCriacao']
	search_fields = ["nomeRedeSocial",'dataCriacao','dataCriacao']
admin.site.register(redeSocial,redeSocialAdmin)

class estiloAdmin(admin.ModelAdmin):
    pass
admin.site.register(estilo,estiloAdmin)

class formsHomeAdmin(admin.ModelAdmin):
	list_display 	= ["nome",'email','dataCriacao']
	search_fields = ["nome",'dataCriacao']
admin.site.register(formsHome,formsHomeAdmin)
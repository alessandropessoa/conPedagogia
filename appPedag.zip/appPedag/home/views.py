from django.shortcuts import render
from django.http import response
from .models import *
# Create your views here.

def pagina(requests):
    html		= 'home/index.html'
    contexto	= {
    "heroSection":heroSection.objects.all(),
    "descricao":descricao.objects.all(),
    "comodFunc":comoFunciona.objects.all(),
    "port":portifolio.objects.all(),
    "listac":listaConcursos.objects.all(),
    "redeSocial":redeSocial.objects.all(),
    "estilo":estilo.objects.all()[0].bgColor,
    }
    
    bdMsg = msg()
    if requests.method == "GET":
        campos = requests.GET
        if campos.get("btnSbmt")=="ok":
            bdMsg.nome = campos.get("nome")
            bdMsg.email = campos.get("email")
            bdMsg.cpf = campos.get("cpf")
            bdMsg.telefone = campos.get("telefone")
            bdMsg.descricao = campos.get("mensagem")
            bdMsg.save()
    return render(requests,html,contexto)
    

def cadastro(requests):
    html		= 'home/forms.html'
    contexto	= {

    }

    return render(requests,html,contexto)